const h={LISTS:"engagekit-profile-lists",PROFILE_DATA:"engagekit-profile-data"};let L=!1;(()=>{if(document.getElementById("profile-extract-style"))return;const t=document.createElement("style");t.id="profile-extract-style",t.textContent=`
    /* Spinner animation */
    @keyframes profileExtractSpin {
      from { transform: rotate(0deg) }
      to { transform: rotate(360deg) }
    }
    .profile-extract-btn--loading {
      animation: profileExtractSpin 1s linear infinite !important;
      opacity: 0.6 !important;
      box-shadow: none !important;
    }

    /* Wiggle animation */
    @keyframes profileExtractWiggle {
      0% { transform: rotate(0deg) }
      25% { transform: rotate(2deg) }
      75% { transform: rotate(-2deg) }
      100% { transform: rotate(0deg) }
    }
    .profile-extract-btn--wiggle {
      animation: profileExtractWiggle 1.5s ease-in-out infinite;
    }

    /* Letter animation */
    @keyframes profileExtractLetterSlide {
      0% { transform: translateX(-1px) }
      100% { transform: translateX(1px) }
    }
    .profile-extract-btn--wiggle .profile-extract-btn-letter {
      display: inline-block;
      animation: profileExtractLetterSlide 2s ease-in-out infinite alternate;
    }

    /* Push-down state */
    .profile-extract-btn--down {
      transform: translate(1px, 1px) !important;
      box-shadow: none !important;
    }

    /* Dropdown styles */
    .profile-extract-dropdown {
      position: absolute;
      top: 100%;
      left: 0;
      background: white;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 1000;
      min-width: 200px;
      max-height: 320px; /* Height for ~10 rows */
      display: none;
      flex-direction: column;
    }

    .profile-extract-dropdown.show {
      display: flex;
    }

    .profile-extract-dropdown-content {
      max-height: 260px; /* Space for 10 rows */
      overflow-y: auto;
      padding: 8px 0;
    }

    .profile-extract-dropdown-item {
      display: flex;
      align-items: center;
      padding: 8px 12px;
      cursor: pointer;
      font-size: 14px;
      color: #333;
      transition: background-color 0.1s ease;
    }

    .profile-extract-dropdown-item:hover {
      background-color: #f5f5f5;
    }

    .profile-extract-dropdown-checkbox {
      margin-right: 8px;
      cursor: pointer;
    }

    .profile-extract-dropdown-search {
      border-bottom: 1px solid #ddd;
      padding: 8px;
      background: #f9f9f9;
      border-radius: 8px 8px 0 0;
      position: sticky;
      top: 0;
      z-index: 10;
    }

    .profile-extract-dropdown-search-input {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      outline: none;
      background: white;
    }

    .profile-extract-dropdown-search-input:focus {
      border-color: #e6007a;
      box-shadow: 0 0 0 2px rgba(230, 0, 122, 0.1);
    }

    .profile-extract-dropdown-search-input::placeholder {
      color: #999;
    }
  `,document.head.appendChild(t)})();function k(){const t=window.location.href;return t.includes("linkedin.com/in/")&&!t.includes("/edit/")}async function C(){console.log("🔄 [Lists] Starting load operation from chrome.storage.local");try{const t=await chrome.storage.local.get([h.LISTS]);console.log("🔍 [Lists] Raw storage result:",t);const e=t[h.LISTS];if(e&&Array.isArray(e))return console.log("✅ [Lists] Successfully loaded from chrome.storage:",e.length,"lists ->",e),e;console.log("📋 [Lists] No valid list data found, stored value:",e)}catch(t){console.error("❌ [Lists] Error loading from chrome.storage:",t),console.error("❌ [Lists] Error details:",{name:t==null?void 0:t.name,message:t==null?void 0:t.message,stack:t==null?void 0:t.stack})}return console.log("📋 [Lists] Returning empty array as fallback"),[]}async function S(t){console.log("🔄 [Lists] Starting save operation to chrome.storage.local with:",t);try{const e={[h.LISTS]:t};console.log("🔍 [Lists] Data being saved:",e),await chrome.storage.local.set(e),console.log("✅ [Lists] Successfully saved to chrome.storage:",t.length,"lists");const o=(await chrome.storage.local.get([h.LISTS]))[h.LISTS];Array.isArray(o)&&o.length===t.length?console.log("✅ [Lists] Storage verification successful - data persisted correctly"):console.error("❌ [Lists] Storage verification failed - saved data doesn't match:",{expected:t,actual:o})}catch(e){console.error("❌ [Lists] Error saving to chrome.storage:",e),console.error("❌ [Lists] Error details:",{name:e==null?void 0:e.name,message:e==null?void 0:e.message,stack:e==null?void 0:e.stack})}}async function y(){console.log("🔄 [Profile Data] Starting load operation from chrome.storage.local");try{const t=await chrome.storage.local.get([h.PROFILE_DATA]);console.log("🔍 [Profile Data] Raw storage result:",t);const e=t[h.PROFILE_DATA];if(e&&typeof e=="object")return console.log("✅ [Profile Data] Successfully loaded from chrome.storage:",Object.keys(e).length,"profiles ->",Object.keys(e)),e;console.log("📊 [Profile Data] No valid profile data found, stored value:",e)}catch(t){console.error("❌ [Profile Data] Error loading from chrome.storage:",t),console.error("❌ [Profile Data] Error details:",{name:t==null?void 0:t.name,message:t==null?void 0:t.message,stack:t==null?void 0:t.stack})}return console.log("📊 [Profile Data] Returning empty object as fallback"),{}}async function v(t){console.log("🔄 [Profile Data] Starting save operation to chrome.storage.local with:",Object.keys(t).length,"profiles"),console.log("🔍 [Profile Data] Profile URLs being saved:",Object.keys(t));try{const e={[h.PROFILE_DATA]:t};console.log("🔍 [Profile Data] Data structure being saved:",e),await chrome.storage.local.set(e),console.log("✅ [Profile Data] Successfully saved to chrome.storage:",Object.keys(t).length,"profiles");const o=(await chrome.storage.local.get([h.PROFILE_DATA]))[h.PROFILE_DATA];o&&typeof o=="object"&&Object.keys(o).length===Object.keys(t).length?console.log("✅ [Profile Data] Storage verification successful - data persisted correctly"):console.error("❌ [Profile Data] Storage verification failed - saved data doesn't match:",{expectedCount:Object.keys(t).length,actualCount:o?Object.keys(o).length:0,expectedKeys:Object.keys(t),actualKeys:o?Object.keys(o):[]})}catch(e){console.error("❌ [Profile Data] Error saving to chrome.storage:",e),console.error("❌ [Profile Data] Error details:",{name:e==null?void 0:e.name,message:e==null?void 0:e.message,stack:e==null?void 0:e.stack})}}function P(){try{const e=window.location.href.match(/(https:\/\/www\.linkedin\.com\/in\/[^/?#]+)/i),n=(e==null?void 0:e[1])??null;return console.log("🔍 [Profile URL] Current profile:",n),n}catch(t){return console.error("❌ [Profile URL] Error extracting current profile URL:",t),null}}function D(){try{console.log("🎯 [Profile Extract] Starting profile data extraction...");const t=document.querySelector("#profile-content > div > div.scaffold-layout.scaffold-layout--main-aside.scaffold-layout--reflow.pv-profile.pvs-loader-wrapper__shimmer--animate > div > div > main > section.artdeco-card");if(!t)return console.error("❌ [Profile Extract] Profile section not found"),null;const e=a=>{var l;return a?(l=a.textContent)==null?void 0:l.trim():void 0},n=(a,l)=>a?a.getAttribute(l):void 0,o=t.querySelector("div.ph5"),i=n(o==null?void 0:o.querySelector('img[class*="top-card-profile-picture__image--show"]'),"src");let m;const p=t.querySelectorAll('a[href*="/in/"]');if(p&&p.length>0){const a=Array.from(p)[0];let l=a.href.startsWith("http")?a.href:window.location.origin+a.getAttribute("href");const x=l.match(/(https:\/\/www\.linkedin\.com\/in\/[^/?#]+)/i);m=x?x[1]:l}else{const a=window.location.origin+window.location.pathname,l=a.match(/(https:\/\/www\.linkedin\.com\/in\/[^/?#]+)/i);m=l?l[1]:a}const f=e(o==null?void 0:o.querySelector('h1[class*="v-align-middle"], h1.t-24')),s=e(o==null?void 0:o.querySelector("div.text-body-medium.break-words"));let c;const g=document.querySelectorAll('a[href*="profileUrn=urn%3Ali%3Afsd_profile%3A"]');for(const a of g){const l=a.getAttribute("href");if(l)try{const u=new URL(l,window.location.origin).searchParams.get("profileUrn");if(u){const w=decodeURIComponent(u).split(":");c=w[w.length-1],console.log("🎯 [URN Extract] Found URN from encoded link:",c);break}}catch{console.log("⚠️ [URN Extract] URL parsing failed, trying regex fallback");const u=l.match(/profileUrn=urn%3Ali%3Afsd_profile%3A([A-Za-z0-9_-]+)/);if(u&&u[1]){c=u[1],console.log("🎯 [URN Extract] Found URN from regex fallback:",c);break}}}const r={profilePhotoUrl:i||void 0,profileUrl:m||P()||"",fullName:f||void 0,headline:s||void 0,profileUrn:c||void 0,lists:[]};return console.log("✅ [Profile Extract] Extracted profile data:",{profilePhotoUrl:r.profilePhotoUrl?"✓ Found":"❌ Missing",profileUrl:r.profileUrl||"❌ Missing",fullName:r.fullName||"❌ Missing",headline:r.headline||"❌ Missing",profileUrn:r.profileUrn||"❌ Missing",listsCount:r.lists.length}),console.log("🔍 [Profile Extract] Full extracted data:",r),r.profileUrn?console.log("✅ [URN Extract] Successfully extracted profileUrn:",r.profileUrn):(console.log("❌ [URN Extract] Failed to extract profileUrn - checking available elements:"),console.log("  - Encoded URN links found:",document.querySelectorAll('a[href*="profileUrn=urn%3Ali%3Afsd_profile%3A"]').length),console.log("  - All links with profileUrn found:",document.querySelectorAll('a[href*="profileUrn="]').length)),r}catch(t){return console.error("❌ [Profile Extract] Error extracting profile data:",t),null}}async function A(t){const n=(await y())[t],o=(n==null?void 0:n.lists)||[];return console.log(`📋 [Profile Lists] Profile ${t} is in ${o.length} lists:`,o),o}async function U(t,e){console.log("🎯 [Data Flow] addProfileToList called with:",{profileUrl:t,listName:e}),console.log(`➕ [Profile Lists] Adding ${t} to list "${e}"`);const n=await y();console.log(`🎯 [Data Flow] Loaded ${Object.keys(n).length} profiles from storage`);let o=n[t];if(!o){console.log("🆕 [Profile Lists] Profile not in storage, extracting from page...");const i=D();if(!i){console.error("❌ [Profile Lists] Failed to extract profile data, cannot add to list");return}o=i,n[t]=o,console.log("✅ [Profile Lists] New profile created and stored")}o.lists.includes(e)?console.log(`ℹ️ [Profile Lists] Profile already in list "${e}"`):(o.lists.push(e),console.log(`✅ [Profile Lists] Added "${e}" to profile. Total lists: ${o.lists.length}`),console.log("🎯 [Data Flow] Profile lists now:",o.lists)),console.log(`🎯 [Data Flow] Saving updated profile data (${Object.keys(n).length} profiles)...`),await v(n),console.log("💾 [Profile Lists] Profile data updated in storage"),console.log("✅ [Data Flow] addProfileToList completed successfully")}async function $(t,e){console.log(`➖ [Profile Lists] Removing ${t} from list "${e}"`);const n=await y(),o=n[t];if(!o){console.log("ℹ️ [Profile Lists] Profile not found in storage, nothing to remove");return}const i=o.lists.indexOf(e);i>-1?(o.lists.splice(i,1),console.log(`✅ [Profile Lists] Removed "${e}" from profile. Remaining lists: ${o.lists.length}`)):console.log(`ℹ️ [Profile Lists] Profile was not in list "${e}"`),o.lists.length===0&&(delete n[t],console.log("🗑️ [Profile Lists] Profile removed from storage (no lists remaining)")),await v(n),console.log("💾 [Profile Lists] Profile data updated in storage")}async function R(t){console.log(`🧹 [Profile Cleanup] Starting cleanup for deleted list: "${t}"`);const e=await y(),n=Object.keys(e);let o=0,i=0,m=0;console.log(`🔍 [Profile Cleanup] Checking ${n.length} profiles for list dependencies`),n.forEach(p=>{const f=e[p];if(!f)return;const s=f.lists.indexOf(t);s>-1&&(o++,f.lists.splice(s,1),console.log(`➖ [Profile Cleanup] Removed "${t}" from ${p}. Lists remaining: ${f.lists.length}`),f.lists.length===0?(delete e[p],i++,console.log(`🗑️ [Profile Cleanup] Deleted profile ${p} (no lists remaining)`)):(m++,console.log(`✅ [Profile Cleanup] Kept profile ${p} (${f.lists.length} lists remaining: ${f.lists.join(", ")})`)))}),o>0&&(await v(e),console.log("💾 [Profile Cleanup] Updated profile storage after cleanup")),console.log(`📊 [Profile Cleanup] Cleanup complete for "${t}":`),console.log(`   • Profiles affected: ${o}`),console.log(`   • Profiles cleaned: ${m}`),console.log(`   • Profiles deleted: ${i}`),console.log(`   • Profiles remaining: ${Object.keys(e).length}`)}async function T(){const t=document.createElement("div");t.className="profile-extract-dropdown";const e=document.createElement("div");e.className="profile-extract-dropdown-search";const n=document.createElement("input");n.type="text",n.className="profile-extract-dropdown-search-input",n.placeholder="Search lists...",e.appendChild(n);const o=document.createElement("div");o.className="profile-extract-dropdown-content";let i=await C();function m(){const s=document.createElement("div");s.className="profile-extract-dropdown-item",s.style.borderBottom="1px solid #ddd",s.style.marginBottom="8px",s.style.background="#f9f9f9",s.style.position="sticky",s.style.top="0",s.style.zIndex="5";const c=document.createElement("span");c.textContent="+ ",c.style.color="#e6007a",c.style.fontWeight="bold";const g=document.createElement("span");return g.textContent="New List",g.style.cursor="pointer",g.style.color="#666",s.appendChild(c),s.appendChild(g),s.addEventListener("click",()=>{p(s)}),s}function p(s){s.innerHTML="";const c=document.createElement("input");c.type="text",c.className="profile-extract-dropdown-search-input",c.placeholder="Enter list name...",c.style.fontSize="14px",c.style.padding="6px 8px",s.appendChild(c),c.focus();const g=async()=>{const r=c.value.trim(),a=r.toLowerCase(),l=i.map(u=>u.toLowerCase());r&&a!=="all"&&!l.includes(a)&&(i.push(r),await S(i),await f(i));const x=m();o.removeChild(s),o.insertBefore(x,o.firstChild)};c.addEventListener("keydown",r=>{if(r.key==="Enter")r.preventDefault(),g();else if(r.key==="Escape"){const a=m();o.removeChild(s),o.insertBefore(a,o.firstChild)}}),c.addEventListener("blur",g)}async function f(s){o.innerHTML="",o.appendChild(m());const c=P(),g=c?await A(c):[];s.forEach(r=>{const a=document.createElement("div");a.className="profile-extract-dropdown-item",a.dataset.listName=r.toLowerCase();const l=document.createElement("input");l.type="checkbox",l.className="profile-extract-dropdown-checkbox";const x=`list-checkbox-${r.replace(/\s+/g,"-")}-${btoa(r).replace(/[^a-zA-Z0-9]/g,"")}`;l.id=x,l.checked=g.includes(r),console.log(`📍 [Profile Extract] Rendering ${r}: checked=${l.checked}, profile lists=${g.length}`);const u=document.createElement("label");u.htmlFor=x,u.textContent=r,u.style.cursor="pointer",l.addEventListener("change",async()=>{console.log(`📍 [Profile Extract] Change event triggered for ${r}: ${l.checked}`);const d=P();if(!d){console.error("❌ [Profile Extract] Cannot get current profile URL");return}l.checked?await U(d,r):await $(d,r)}),a.appendChild(l),a.appendChild(u);{const d=document.createElement("span");d.innerHTML="🗑️",d.style.cursor="pointer",d.style.marginLeft="auto",d.style.padding="4px",d.style.fontSize="14px",d.style.opacity="0.6",d.style.transition="opacity 0.2s ease",d.title=`Delete "${r}" list`,d.addEventListener("mouseenter",()=>{d.style.opacity="1"}),d.addEventListener("mouseleave",()=>{d.style.opacity="0.6"}),d.addEventListener("click",async w=>{if(w.stopPropagation(),confirm(`Are you sure you want to delete the "${r}" list?`)){const E=i.indexOf(r);E>-1&&(i.splice(E,1),await S(i)),await R(r),await f(i),console.log(`📍 [Profile Extract] Deleted list: ${r}`)}}),a.style.display="flex",a.style.alignItems="center",a.appendChild(d)}a.addEventListener("click",d=>{const w=d.target;w!==l&&w!==u&&w.innerHTML!=="🗑️"&&(console.log(`📍 [Profile Extract] Item clicked for ${r}, toggling from ${l.checked} to ${!l.checked}`),l.checked=!l.checked,l.dispatchEvent(new Event("change")))}),o.appendChild(a)})}return await f(i),n.addEventListener("input",async s=>{const c=s.target.value.toLowerCase(),g=i.filter(r=>r.toLowerCase().includes(c));await f(g)}),t.appendChild(e),t.appendChild(o),t}async function I(){const t=document.createElement("div");t.style.position="relative",t.style.display="inline-block";const e=document.createElement("button");e.type="button",e.className="profile-extract-btn";const n=document.createElement("span");n.className="profile-extract-btn-letter",n.textContent="List",e.appendChild(n),Object.assign(e.style,{background:"#e6007a",color:"white",border:"none",borderRadius:"24px",padding:"8px 16px",fontSize:"14px",fontWeight:"600",cursor:"pointer",display:"inline",alignItems:"center",justifyContent:"center",marginLeft:"4px",marginTop:"0px",height:"32px",minWidth:"auto",transition:"all 0.1s ease",boxShadow:"2px 2px 0 #000",zIndex:"1"}),e.classList.add("profile-extract-btn--wiggle");const o=await T();t.appendChild(e),t.appendChild(o);let i;const m=()=>{clearTimeout(i),o.classList.add("show")},p=()=>{i=setTimeout(()=>{o.classList.remove("show")},200)};return e.addEventListener("mouseenter",()=>{e.classList.contains("profile-extract-btn--loading")||(e.classList.remove("profile-extract-btn--wiggle"),e.style.background="#b8005a"),m()}),e.addEventListener("mouseleave",()=>{!e.classList.contains("profile-extract-btn--loading")&&!e.classList.contains("profile-extract-btn--down")&&(e.classList.add("profile-extract-btn--wiggle"),e.style.background="#e6007a"),p()}),o.addEventListener("mouseenter",()=>{clearTimeout(i)}),o.addEventListener("mouseleave",p),e.addEventListener("mousedown",()=>{e.classList.add("profile-extract-btn--down"),e.classList.remove("profile-extract-btn--wiggle")}),e.addEventListener("mouseup",()=>{e.classList.remove("profile-extract-btn--down"),!e.classList.contains("profile-extract-btn--loading")&&!e.matches(":hover")&&e.classList.add("profile-extract-btn--wiggle")}),e.addEventListener("click",f=>{f.preventDefault(),console.log("🔍 Profile extract button clicked!")}),t}async function O(t){const e=t.parentElement;if(!e){console.log("📍 [Profile Extract] Overflow button parent not found");return}const n=e.parentElement;if(!n){console.log("📍 [Profile Extract] Grandparent element not found for placement");return}if(n.querySelector(".profile-extract-button-container")){console.log("📍 [Profile Extract] Button already exists in container, skipping");return}const i=await I();i.classList.add("profile-extract-button-container"),e.nextSibling?n.insertBefore(i,e.nextSibling):n.appendChild(i),console.log("✅ [Profile Extract] Button added after overflow button's parent!")}async function b(){if(L){console.log("📍 [Profile Extract] Button creation already in progress, skipping");return}L=!0;try{console.log("🔍 [Profile Extract] Looking for overflow action button under scaffold-layout__inner...");const t=document.querySelector('[class*="scaffold-layout__inner"]');if(!t){console.log("❌ [Profile Extract] No scaffold-layout__inner element found");return}console.log("📍 [Profile Extract] Found scaffold-layout__inner element");const e=t.querySelector('[id*="profile-overflow-action"]');e?(console.log("📍 [Profile Extract] Found overflow button in scaffold element:",e),await O(e)):console.log("❌ [Profile Extract] No overflow action button found under scaffold-layout__inner")}finally{L=!1}}function _(){console.log("🚀 [Profile Extract] Initializing on profile page..."),b().catch(console.error),setTimeout(()=>{b().catch(console.error)},1e3),console.log("✅ [Profile Extract] Button initialization complete")}function F(){console.log("🔄 [Profile Extract] Setting up URL monitoring for SPA navigation...");let t=window.location.href;k()&&_();const e=()=>{const o=window.location.href;o!==t&&(console.log("🔄 [Profile Extract] URL changed:",{from:t,to:o}),t=o),k()&&b().catch(console.error)};new MutationObserver(e).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("popstate",e),console.log("✅ [Profile Extract] URL monitoring initialized")}export{y as a,v as b,F as i,C as l,S as s};
